export function getDataA() {
    return [
        { month: 'Jan', low: -1, high: 0 },
        { month: 'Mar', low: -3, high: 1 },
        { month: 'May', low: -1.9, high: -1.3 },
        { month: 'Jul', low: -2.1, high: -1.1 },
        { month: 'Sep', low:-2.9, high: -0.6 },
        { month: 'Nov', low: -0.6, high: -0.2  }
    ];
  }
  
  export function getDataB() {
    return [
        { month: 'Jan-Feb', low: 0, high: 0},
        { month: 'Mar-Apr', low: -1.2, high: 0},
        { month: 'May-Jun', low: -1.1, high: 0},
        { month: 'Jul-Aug', low: -1.2, high: 0},
        { month: 'Sep-Oct', low: -0.3, high: 0},
        { month: 'Nov-Dec', low: -0.4, high: 0 }
    ];
  }

  export function getDataC() {
    return [
        { month: 'Jan-Feb', low: 0, high: 7 },
        { month: 'Mar-Apr', low: 0, high: 5.9 },
        { month: 'May-Jun', low: 0, high: 6 },
        { month: 'Jul-Aug', low: 0, high: 7 },
        { month: 'Sep-Oct', low: 0, high: 5},
        { month: 'Nov-Dec', low: 0, high: 2.1 }
    ];  }
  export function getDataD() {
    return [
        { month: 'Jan-Feb', low: 7, high: 11.8},
        { month: 'Mar-Apr', low: 5.9, high: 13.8},
        { month: 'May-Jun', low: 6, high: 11},
        { month: 'Jul-Aug', low: 7, high: 12.3},
        { month: 'Sep-Oct', low: 5, high: 9.9},
        { month: 'Nov-Dec', low: 2.1, high: 6 }
    ];
  }
  