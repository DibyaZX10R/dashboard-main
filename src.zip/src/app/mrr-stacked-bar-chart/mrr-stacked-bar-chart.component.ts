import { Component, OnInit } from '@angular/core';
import { AgAxisLabelFormatterParams } from 'ag-charts-community';
import { getDataA, getDataB, getDataC, getDataD } from './data';

@Component({
  selector: 'app-mrr-stacked-bar-chart',
  templateUrl: './mrr-stacked-bar-chart.component.html',
  styleUrls: ['./mrr-stacked-bar-chart.component.css']
})
export class MrrStackedBarChartComponent implements OnInit {
  options: any;

  ngOnInit() {

  const dataA = getDataA();
  const dataB = getDataB();
  const dataC = getDataC();
  const dataD = getDataD();

  console.log('Data A:', dataA);
  console.log('Data B:', dataB);
  console.log('Data C:', dataC);
  console.log('Data D:', dataD);
    this.options = {
      autoSize: true,
      title: {
        text: 'MRR'
      },
      // data: [
      //   { period: 'Jan-Feb', segmentA: 4000, segmentB: 2000, segmentC: 1000, segmentD: -2000 },
      //   { period: 'Mar-Apr', segmentA: 6000, segmentB: 4000, segmentC: 2000, segmentD: -4000 },
      //   { period: 'May-Jun', segmentA: 5000, segmentB: 3000, segmentC: 1500, segmentD: -3000 },
      //   { period: 'Jul-Aug', segmentA: 5500, segmentB: 3500, segmentC: 1800, segmentD: -3200 },
      //   { period: 'Sep-Oct', segmentA: 4800, segmentB: 3000, segmentC: 1600, segmentD: -2800 },
      //   { period: 'Nov-Dec', segmentA: 4200, segmentB: 2500, segmentC: 1400, segmentD: -2400 }
      // ],
     
      series: [
        {
          
          data:getDataA(),
          type: 'range-bar',
          xKey: 'month',
          
          yLowKey: 'low',
          yHighKey: 'high',
          
        },
        {
          
          data:getDataB(),
          type: 'range-bar',
          xKey: 'month',
          
          yLowKey: 'low',
          yHighKey: 'high',
          
        },{
          
          data:getDataC(),
          type: 'range-bar',
          xKey: 'month',
          
          yLowKey: 'low',
          yHighKey: 'high',
          
        },{
          
          data:getDataD(),
          type: 'range-bar',
          xKey: 'month',
          
          yLowKey: 'low',
          yHighKey: 'high',
          
        },
      ],
      axes: [
        {
          type: 'category',
          position: 'bottom',
          title: {
            text: 'Period'
          },
          label: {
            color: "#0000FF",
            formatter: ({ value }: { value: any }) => `${value}` 
          }
        },
        {
          type: 'number',
          position: 'left',
          title: {
            text: 'MRR'
          },
          label: {
            color: "#0000FF",
            formatter: (params: AgAxisLabelFormatterParams) => `$${params.value / 1000}K`
          },
          min: -4,
          max: 14
        }
      ],
      legend: {
        position: 'bottom',
        spacing: 20,
        item: {
          marker: {
            size: 12
          },
          label: {
            color: "#FF0000",
            fontSize: 12
          }
        }
      },
      width: 500,
      height: 500,
    };
  }
}
