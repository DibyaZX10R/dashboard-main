import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MrrStackedBarChartComponent } from './mrr-stacked-bar-chart.component';

describe('MrrStackedBarChartComponent', () => {
  let component: MrrStackedBarChartComponent;
  let fixture: ComponentFixture<MrrStackedBarChartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MrrStackedBarChartComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MrrStackedBarChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
